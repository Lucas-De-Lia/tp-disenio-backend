const REGISTRAR_BEDEL = {
    "username": "nombre_de_usuario",
    "nombre": "nombre_bedel",
    "apellido": "apellido_bedel",
    "password": "asdASD123*",
    "repeatedPassword": "asdASD123*",
    "turno": "TARDE",
    "registradoPor": "ADMIN" // Se puede colocar ya sea el username o el id del administrador que lo registra
}

const MODIFICAR_BEDEL = {
    "idUsuario": "b635e6e2-0c2c-48ef-ac9d-5166089cf968",
    "nombre": "Nuevo Nombre",
    "apellido": "Nuevo Apellido",
    "password": "asdASD123*", // Solo si se quiere cambiar la contraseña
    "repeatedPassword": "asdASD123*", // Solo si se quiere cambiar la contraseña
    "turno": "TARDE"
}


