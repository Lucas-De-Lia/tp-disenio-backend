package com.tpdisenio.gSM3C.exception;

public class AdministradorAlreadyExistsException extends RuntimeException{
    public AdministradorAlreadyExistsException(String message) {
        super(message);
    }
}
