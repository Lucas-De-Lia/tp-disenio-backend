package com.tpdisenio.gSM3C.exception;

public class CuatrimestreNotFoundException extends RuntimeException {
    public CuatrimestreNotFoundException(String message) {
        super(message);
    }
}
