package com.tpdisenio.gSM3C.exception;

public class AdministradorNotFoundException extends RuntimeException {
    public AdministradorNotFoundException(String message) {
        super(message);
    }
}