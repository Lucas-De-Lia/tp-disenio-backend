package com.tpdisenio.gSM3C.exception;

public class BedelAlreadyExistsException extends RuntimeException {
    public BedelAlreadyExistsException(String message) {
        super(message);
    }
}
