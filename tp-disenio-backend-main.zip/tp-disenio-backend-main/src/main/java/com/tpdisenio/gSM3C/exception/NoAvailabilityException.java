package com.tpdisenio.gSM3C.exception;

public class NoAvailabilityException extends RuntimeException {
    public NoAvailabilityException(String message) {
        super(message);
    }
}