package com.tpdisenio.gSM3C.exception;

public class BedelNotFoundException extends RuntimeException {
    public BedelNotFoundException(String message) {
        super(message);
    }
}