package com.tpdisenio.gSM3C.exception;

public class DuplicatedDayException extends RuntimeException {
    public DuplicatedDayException(String message) {
        super(message);
    }
}

