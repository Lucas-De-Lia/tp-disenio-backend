package com.tpdisenio.gSM3C;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpdisenioApplicationTests {

	@Test
	void contextLoads() {
	}

}
